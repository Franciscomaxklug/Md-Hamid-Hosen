from calculator import calculate
from dbHandler import loadGradeSheet
from updater import updateGradeSheet


def main():
    # The loop will start running as soon as you run the script.
    while True:
        print('Select your desired option:')
        print('\t1. Calculate GPA')
        print('\t2. Update Grade Sheet')
        print('\t3. Show Grade Sheet')
        print('\t4. Exit')
        ans = input('Option no: ').strip()
        print()
        if ans == '1':
            print("///////////")
            print("Your GPA is", "{:.2f}".format(calculate()))
            print()
            print("//////////")
        elif ans == '2':
            print(updateGradeSheet())
        elif ans == '3':
            loadGradeSheet(printing=True)
        elif ans == '4':
            break
        else:
            print('Wrong Input!')


if __name__ == '__main__':
    main()
