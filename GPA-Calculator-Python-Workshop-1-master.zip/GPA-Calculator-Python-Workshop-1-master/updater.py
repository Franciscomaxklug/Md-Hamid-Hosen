from dbHandler import loadGradeSheet, saveGradeSheet


def updateGradeSheet():
    """This function is used to update the Grade Sheet. Like changing the points
        of the respective grades."""

    gradeSheet = loadGradeSheet() # loading the dictionary.

    print('Enter grades that you want to update (Example: a+=4.0,b+=3.6)')
    needToUpdateGrades = tuple(input().split(','))

    for i in needToUpdateGrades:
        grade, point = i.split('=')
        gradeSheet[grade.strip().upper()] = float(point.strip())

    return saveGradeSheet(gradeSheet)


if __name__ == '__main__':
    print("This is module. Go to main.py")
