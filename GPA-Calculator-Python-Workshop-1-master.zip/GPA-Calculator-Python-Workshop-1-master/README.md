# GPA Calculator Python Workshop 1
The simple and very easy toy project(console based) that we showed in our workshop named "Fundamentals of Python 2020" .  
