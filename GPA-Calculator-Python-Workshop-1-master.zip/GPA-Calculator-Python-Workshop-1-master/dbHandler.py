import json


def loadGradeSheet(printing = False):
    """It will load the grade sheet (json file) and store it to a dictionary"""

    with open('GradeSheet.json', 'r', encoding='utf-8') as file:
        grades = file.read()
        grades = json.loads(grades)
    if printing is True:
        print(json.dumps(grades, indent=4))
    else:
        return grades


def saveGradeSheet(grades):
    """Save the grade sheet permanently (dumping into the json file)."""

    with open('GradeSheet.json', 'w', encoding='utf-8') as file:
        grades = json.dumps(grades, indent=4)
        file.write(grades)
    return grades


if __name__ == '__main__':
    print("This is a module. Go to main.py")
