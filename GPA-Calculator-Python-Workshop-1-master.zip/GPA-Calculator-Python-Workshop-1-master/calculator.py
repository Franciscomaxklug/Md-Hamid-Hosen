from dbHandler import loadGradeSheet


def calculate():
    """All the calculations are done by this function."""

    gradeSheet = loadGradeSheet()
    theoryList = input('Theory grades (Use comma for seperation): ').split(',')
    labList = input('Laboratory grades (Use comma for seperation): ').split(',')
    theoryCredit = float(input('Per Subject Credit (Theory): ').strip())
    labCredit = float(input('Per Subject Credit (Lab):').strip())

    totalCredit = (len(theoryList) * theoryCredit) + (len(labList) * labCredit)

    theorySum = 0
    for i in theoryList:
        theorySum += theoryCredit * gradeSheet[i.upper()]

    labSum = 0
    for i in labList:
        labSum += labCredit * gradeSheet[i.upper()]

    gpa  = theorySum + labSum
    gpa /= totalCredit
    return gpa

if __name__ == '__main__':
    print("This is module! Go to main.py")
